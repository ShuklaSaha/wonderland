package com.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.dao.mapper.PermissionMapper;
import com.dao.mapper.RoleMapper;
import com.dao.mapper.UserMapper;
import com.dao.mapper.UserTOMapper;
import com.domain.Permission;
import com.domain.Role;
import com.domain.User;
import com.domain.UserTO;
import com.logger.MyLogFactory;
import com.logger.MyLogger;

@Repository
public class UserDaoImpl implements UserDao {

	private static final MyLogger logger = MyLogFactory.getLoggerInstance(UserDaoImpl.class.getName());

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate template) {
		this.jdbcTemplate = template;
	}

	public User getUserTreeByUserName(String userName) {
		String query = "SELECT U.USER_ID, U.USERNAME, U.PASSWORD, U.STATUS, R.ROLE_ID, R.ROLE_NAME, P.PERMISSION_ID, P.PERMISSION_NAME";
		query = query + " FROM USERS U, USER_ROLE UR, ROLES R, ROLE_PERMISSION RP, PERMISSIONS P";
		query = query + " WHERE U.USERNAME = '" + userName + "'";
		query = query + " AND U.USER_ID = UR.USER_ID";
		query = query + " AND UR.ROLE_ID = R.ROLE_ID";
		query = query + " AND R.ROLE_ID = RP.ROLE_ID";
		query = query + " AND RP.PERMISSION_ID = P.PERMISSION_ID";
		logger.log(MyLogger.INFO, query);
		List<UserTO> userTOList = jdbcTemplate.query(query, new UserTOMapper());
		return mapToUser(userTOList);
	}

	public User setUserTree(User user) {
		boolean status = false;
		Long userId = user.getUserId();
		Set<Role> roles = user.getRoles();
		if (roles != null && !roles.isEmpty()) {
			for (Role role : roles) {
				Long roleId = role.getRoleId();
				status = insertIntoUserRole(userId, roleId);
				Set<Permission> permissions = role.getPermissions();
				if (permissions != null && !permissions.isEmpty()) {
					for (Permission permission : permissions) {
						Long permissionId = permission.getPermissionId();
						status = insertIntoRolePermission(roleId, permissionId);
					}
				} else {
					logger.log(MyLogger.ERROR, "NO Permission to insert");
					status = false;
				}
			}
		} else {
			logger.log(MyLogger.ERROR, "NO Role to insert");
			status = false;
		}
		if (status == true) {
			return getUserTreeByUserName(user.getUserName());
		} else {
			return user;
		}
	}

	private boolean insertIntoUserRole(Long userId, Long roleId) {
		String query = "INSERT INTO `USER_ROLE` (`USER_ID`, `ROLE_ID`) VALUES (" + userId + ", " + roleId + ")";
		int insertCount = jdbcTemplate.update(query);
		if (insertCount == 1) {
			logger.log(MyLogger.INFO, "USER_ROLE created successfully");
			return true;
		} else {
			logger.log(MyLogger.ERROR, "USER_ROLE was NOT created");
			return false;
		}
	}

	private boolean insertIntoRolePermission(Long roleId, Long permissionId) {
		String query = "INSERT INTO `ROLE_PERMISSION` (`ROLE_ID`, `PERMISSION_ID`) VALUES (" + roleId + ", " + permissionId + ")";
		int insertCount = jdbcTemplate.update(query);
		if (insertCount == 1) {
			logger.log(MyLogger.INFO, "ROLE_PERMISSION created successfully");
			return true;
		} else {
			logger.log(MyLogger.ERROR, "ROLE_PERMISSION was NOT created");
			return false;
		}
	}

	public User getUserByUserName(String userName) {
		String query = "SELECT * FROM USERS WHERE USERNAME = '" + userName + "'";
		logger.log(MyLogger.INFO, query);
		List<User> userList = jdbcTemplate.query(query, new UserMapper());
		if (userList != null && !userList.isEmpty()) {
			logger.log(MyLogger.INFO, "User found: " + userName);
			return userList.get(0);
		} else {
			logger.log(MyLogger.INFO, "User NOT found: " + userName);
			return null;
		}
	}

	public User createUser(User newUser) {
		String query = "INSERT INTO `USERS` (`USERNAME`,`PASSWORD`,`STATUS`) VALUES ('" + newUser.getUserName() + "','" + newUser.getPassword() + "','AC')";
		logger.log(MyLogger.INFO, query);
		int insertCount = jdbcTemplate.update(query);
		if (insertCount == 1) {
			logger.log(MyLogger.INFO, "User created successfully");
			return getUserByUserName(newUser.getUserName());
		} else {
			newUser.setUserId(0L);
			logger.log(MyLogger.ERROR, "User was NOT created");
			return newUser;
		}
	}

	public User updateUser(User existingUser) {
		String query = "UPDATE `USERS` SET USERNAME = '" + existingUser.getUserName() + "', PASSWORD = '" + existingUser.getPassword() + "', STATUS = '"
				+ existingUser.getStatus() + "' WHERE USER_ID = " + existingUser.getUserId();
		logger.log(MyLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			logger.log(MyLogger.INFO, "User updated successfully: " + existingUser.getUserName());
			return getUserByUserName(existingUser.getUserName());
		} else {
			existingUser.setUserId(0L);
			logger.log(MyLogger.ERROR, "User was NOT updated: " + existingUser.getUserName());
			return existingUser;
		}
	}

	public User deleteUser(User existingUser) {
		String query = "DELETE FROM `USERS` WHERE USER_ID = " + existingUser.getUserId();
		logger.log(MyLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			existingUser.setUserId(-1L);
			logger.log(MyLogger.INFO, "User deleted successfully: " + existingUser.getUserName());
			return existingUser;
		} else {
			logger.log(MyLogger.ERROR, "User was NOT deleted: " + existingUser.getUserName());
			return existingUser;
		}
	}

	public Set<Role> getAllRolesByUserName(String userName) {
		String query = "SELECT R.* FROM USERS U, ROLES R, USER_ROLE UR WHERE U.USER_ID = UR.USER_ID AND UR.ROLE_ID = R.ROLE_ID AND U.USERNAME = '" + userName
				+ "'";
		logger.log(MyLogger.INFO, query);
		List<Role> roleList = jdbcTemplate.query(query, new RoleMapper());
		if (roleList != null && !roleList.isEmpty()) {
			logger.log(MyLogger.INFO, "Roles found: " + userName);
			return new HashSet<Role>(roleList);
		} else {
			logger.log(MyLogger.INFO, "Role NOT found: " + userName);
			return null;
		}
	}

	public Role createRole(Role newRole) {
		String query = "INSERT INTO `ROLES` (`ROLE_NAME`) VALUES ('" + newRole.getRoleName() + "')";
		logger.log(MyLogger.INFO, query);
		int insertCount = jdbcTemplate.update(query);
		if (insertCount == 1) {
			logger.log(MyLogger.INFO, "Role created successfully: " + newRole.getRoleName());
			return getRoleByRoleName(newRole.getRoleName());
		} else {
			newRole.setRoleId(0L);
			logger.log(MyLogger.ERROR, "Role was NOT created: " + newRole.getRoleName());
			return newRole;
		}
	}

	private Role getRoleByRoleName(String roleName) {
		String query = "SELECT * FROM ROLES WHERE ROLE_NAME = '" + roleName + "'";
		List<Role> roleList = jdbcTemplate.query(query, new RoleMapper());
		if (roleList != null && !roleList.isEmpty()) {
			logger.log(MyLogger.INFO, "Role found: " + roleName);
			return roleList.get(0);
		} else {
			logger.log(MyLogger.INFO, "Role NOT found: " + roleName);
			return null;
		}
	}

	public Role updateRole(Role existingRole) {
		String query = "UPDATE `ROLES` SET ROLE_NAME = '" + existingRole.getRoleName() + "' WHERE ROLE_ID = " + existingRole.getRoleId();
		logger.log(MyLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			logger.log(MyLogger.INFO, "Role updated successfully: " + existingRole.getRoleName());
			return getRoleByRoleName(existingRole.getRoleName());
		} else {
			existingRole.setRoleId(0L);
			logger.log(MyLogger.ERROR, "Role was NOT updated: " + existingRole.getRoleName());
			return existingRole;
		}
	}

	public Role deleteRole(Role existingRole) {
		String query = "DELETE FROM `ROLES` WHERE ROLE_ID = " + existingRole.getRoleId();
		logger.log(MyLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			existingRole.setRoleId(-1L);
			logger.log(MyLogger.INFO, "Role deleted successfully: " + existingRole.getRoleName());
			return existingRole;
		} else {
			logger.log(MyLogger.ERROR, "Role was NOT deleted: " + existingRole.getRoleName());
			return existingRole;
		}
	}

	public Set<Permission> getAllPermissionsByUserName(String userName) {
		String query = "SELECT P.*";
		query = query + " FROM USERS U, USER_ROLE UR, ROLES R, ROLE_PERMISSION RP, PERMISSIONS P";
		query = query + " WHERE U.USERNAME = '" + userName + "'";
		query = query + " AND U.USER_ID = UR.USER_ID";
		query = query + " AND UR.ROLE_ID = R.ROLE_ID";
		query = query + " AND R.ROLE_ID = RP.ROLE_ID";
		query = query + " AND RP.PERMISSION_ID = P.PERMISSION_ID";
		logger.log(MyLogger.INFO, query);
		List<Permission> permissionList = jdbcTemplate.query(query, new PermissionMapper());
		if (permissionList != null && !permissionList.isEmpty()) {
			logger.log(MyLogger.INFO, "Permissions found: " + userName);
			return new HashSet<Permission>(permissionList);
		} else {
			logger.log(MyLogger.INFO, "Role NOT found: " + userName);
			return null;
		}
	}

	public Permission createPermission(Permission newPermission) {
		String query = "INSERT INTO `PERMISSIONS` (`PERMISSION_NAME`) VALUES ('" + newPermission.getPermissionName() + "')";
		logger.log(MyLogger.INFO, query);
		int insertCount = jdbcTemplate.update(query);
		if (insertCount == 1) {
			logger.log(MyLogger.INFO, "Permission created successfully: " + newPermission.getPermissionName());
			return getPermissionByPermissionName(newPermission.getPermissionName());
		} else {
			newPermission.setPermissionId(0L);
			logger.log(MyLogger.ERROR, "Permission was NOT created: " + newPermission.getPermissionName());
			return newPermission;
		}
	}

	private Permission getPermissionByPermissionName(String permissionName) {
		String query = "SELECT * FROM PERMISSIONS WHERE PERMISSION_NAME = '" + permissionName + "'";
		List<Permission> permissionList = jdbcTemplate.query(query, new PermissionMapper());
		if (permissionList != null && !permissionList.isEmpty()) {
			logger.log(MyLogger.INFO, "Permission found: " + permissionName);
			return permissionList.get(0);
		} else {
			logger.log(MyLogger.INFO, "Permission NOT found: " + permissionName);
			return null;
		}
	}

	public Permission updatePermission(Permission existingPermission) {
		String query = "UPDATE `PERMISSIONS` SET PERMISSION_NAME = '" + existingPermission.getPermissionName() + "' WHERE PERMISSION_ID = "
				+ existingPermission.getPermissionId();
		logger.log(MyLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			logger.log(MyLogger.INFO, "Permission updated successfully: " + existingPermission.getPermissionName());
			return getPermissionByPermissionName(existingPermission.getPermissionName());
		} else {
			existingPermission.setPermissionId(0L);
			logger.log(MyLogger.ERROR, "Permission was NOT updated: " + existingPermission.getPermissionName());
			return existingPermission;
		}
	}

	public Permission deletePermission(Permission existingPermission) {
		String query = "DELETE FROM `PERMISSIONS` WHERE PERMISSION_ID = " + existingPermission.getPermissionId();
		logger.log(MyLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			existingPermission.setPermissionId(-1L);
			logger.log(MyLogger.INFO, "Permission deleted successfully: " + existingPermission.getPermissionName());
			return existingPermission;
		} else {
			logger.log(MyLogger.ERROR, "Permission was NOT deleted: " + existingPermission.getPermissionName());
			return existingPermission;
		}
	}

	private User mapToUser(List<UserTO> userTOList) {
		User user = new User();
		Set<Role> roles = new HashSet<Role>();
		for (UserTO to : userTOList) {
			Long userId = Long.valueOf(to.getUserId());
			user.setUserId(userId);
			user.setUserName(to.getUserName());
			user.setPassword(to.getPassword());
			user.setStatus(to.getStatus());
			Role role = new Role();
			Long roleId = Long.valueOf(to.getRoleId());
			role.setRoleId(roleId);
			role.setRoleName(to.getRoleName());
			roles.add(role);
		}
		user.setRoles(roles);
		for (Role role : roles) {
			String roleId = role.getRoleId().toString();
			for (UserTO to : userTOList) {
				Permission permission = new Permission();
				permission.setPermissionId(Long.valueOf(to.getPermissionId()));
				permission.setPermissionName(to.getPermissionName());
				String roleIdString = to.getRoleId();
				if (roleId.equals(roleIdString)) {
					role.getPermissions().add(permission);
				}
			}
		}
		logger.log(MyLogger.INFO, user.toString());
		return user;
	}

	/**
	 * This method is test purpose only.
	 * 
	 * @param userName
	 * @return
	 */
	public User getMockUserByUserName(String userName) {
		User user = new User();
		user.setUserName("diego");
		user.setPassword("diego");

		Set<Role> roles = new HashSet<Role>();
		Role role = new Role();
		role.setRoleName("DIEGO_ROLE");

		Set<Permission> permissions = new HashSet<Permission>();
		Permission permission = new Permission();
		permission.setPermissionName("DIEGO_PERMISSION");
		permissions.add(permission);
		role.setPermissions(permissions);

		roles.add(role);

		user.setRoles(roles);
		return user;
	}

}
