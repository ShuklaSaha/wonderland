package com.service;

import java.util.Set;

import com.domain.Permission;
import com.domain.Role;
import com.domain.User;

public interface UserService {

	User getUserTreeByUserName(String userName);
	User setUserTree(User user);

	User getUserByUserName(String userName);
	User createUser(User newUser);
	User updateUser(User existingUser);
	User deleteUser(User existingUser);

	Set<Role> getAllRolesByUserName(String userName);
	Role createRole(Role newRole);
	Role updateRole(Role existingRole);
	Role deleteRole(Role existingRole);

	Set<Permission> getAllPermissionsByUserName(String userName);
	Permission createPermission(Permission newPermission);
	Permission updatePermission(Permission existingPermission);
	Permission deletePermission(Permission existingPermission);

}