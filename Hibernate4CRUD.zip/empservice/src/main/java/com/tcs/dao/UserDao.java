package com.tcs.dao;

import java.util.List;

import com.tcs.domain.User;

public interface UserDao {

	public User getUser(String userId);

	public List<User> getAllUsers();

	public void saveUser(User user);

	public void updateUser(User user);

	public void deleteUser(String id);

}
