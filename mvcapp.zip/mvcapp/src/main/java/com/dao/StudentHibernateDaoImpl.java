package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.domain.Experiment_Type;
import com.domain.Student;

@Repository("studentHibernateDaoImpl")
public class StudentHibernateDaoImpl implements StudentDao {

	@Autowired
	HibernateTemplate template;

	public Student createStudent(Student student) {
		System.out.println("---------" + student);
		template.save(student);
		return student;
	}

	public Student getStudent(String studentId) {
		Student student = template.get(Student.class, studentId);
		return student;
	}

	public List<Student> getAllStudents() {
		List<Student> studentList = template.findByExample(new Student());
		return studentList;
	}

	public Student updateStudent(Student student) {
		template.update(student);
		return student;
	}

	public boolean deleteStudent(String studentId) {
		template.delete(getStudent(studentId));
		return true;
	}
	public List<Experiment_Type> getExperiments()
	{
		List<Experiment_Type> experiments=template.findByExample(new Experiment_Type());
		return experiments;
	}

}
