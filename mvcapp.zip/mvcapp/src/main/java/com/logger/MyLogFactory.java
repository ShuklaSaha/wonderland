package com.logger;

public class MyLogFactory {

	public static MyLogger getLoggerInstance(final String className) {
		MyLogger logger = new MyLog4j2LoggerImpl(className);
		return logger;
	}
}