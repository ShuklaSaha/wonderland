package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.domain.Student;
import com.service.StudentService;

@Controller
public class StudentMVCController {

	@RequestMapping("/studentRegistrationForm")
	public ModelAndView showStudentRegistrationForm() {
		ModelAndView mav = new ModelAndView("StudentRegistrationForm");
		return mav;
	}

	@RequestMapping("/studentSearchForm")
	public ModelAndView showStudentSearchForm() {
		ModelAndView mav = new ModelAndView("StudentSearchForm");
		return mav;
	}

	@RequestMapping("/studentUpdationForm/{id}")
	public ModelAndView showStudentUpdationForm(@PathVariable("id") String studentId) {
		ModelAndView mav = new ModelAndView("StudentUpdationForm");
		mav.addObject("action", "Update - ");
		try {
			Student student = studentService.getStudent(studentId);
			mav.addObject("student", student);
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error: Student Not Found");
		}
		return mav;
	}

	@Autowired
	StudentService studentService;

	@RequestMapping(value = "/createStudent", method = RequestMethod.POST)
	public ModelAndView createStudent(@ModelAttribute Student student) {
		ModelAndView mav = new ModelAndView("SearchResult");
		mav.addObject("action", "Created - ");
		try {
			Student createdStudent = studentService.createStudent(student);
			mav.addObject("student", createdStudent);
			mav.addObject("message", "Student Created Successfully");
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error: Student Not Created");
		}
		return mav;
	}

	@RequestMapping(value = "/getStudent/{id}", method = RequestMethod.GET)
	public ModelAndView getStudent(@PathVariable("id") String studentId) {
		ModelAndView mav = new ModelAndView("SearchResult");
		mav.addObject("action", "Search Result - ");
		try {
			Student student = studentService.getStudent(studentId);
			if (student != null) {
				mav.addObject("student", student);
			} else {
				mav.addObject("errorMessage", "Student Not Found");
			}
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error: Student Not Found");
		}
		return mav;
	}

	@RequestMapping(value = "/getStudents", method = RequestMethod.GET)
	public ModelAndView getStudents() {
		ModelAndView mav = new ModelAndView("SearchResult");
		mav.addObject("action", "Search Results - ");
		List<Student> students = studentService.getAllStudents();
		mav.addObject("students", students);
		return mav;
	}

	@RequestMapping(value = "/updateStudent", method = RequestMethod.POST)
	public ModelAndView updateStudent(@ModelAttribute Student student) {
		ModelAndView mav = new ModelAndView("SearchResult");
		mav.addObject("action", "Updated - ");
		try {
			Student updatedStudent = studentService.updateStudent(student);
			mav.addObject("student", updatedStudent);
			mav.addObject("message", "Student Updated Successfully");
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error: Student Not Updated");
		}
		return mav;
	}

	@RequestMapping(value = "/deleteStudent/{id}", method = RequestMethod.POST)
	public ModelAndView deleteStudent(@PathVariable("id") String studentId) {
		ModelAndView mav = new ModelAndView("SearchResult");
		mav.addObject("action", "Deleted - ");
		boolean isDeleted = false;
		try {
			isDeleted = studentService.deleteStudent(studentId);
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error: Student Not Deleted");
		}
		if (isDeleted) {
			mav.addObject("message", "Student Deleted Successfully");
		} else {
			mav.addObject("message", "Student Not Deleted");
		}
		return mav;
	}
}
