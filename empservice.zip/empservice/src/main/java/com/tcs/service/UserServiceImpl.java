package com.tcs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.dao.UserDao;
import com.tcs.domain.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	public User getUser(String userId) {
		User user = userDao.getUser(userId);
		return user;
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = userDao.getAllUsers();
		return users;
	}

	@Override
	public String saveUser(User user) {
		// TODO
		String msg = "";
		try {
			userDao.saveUser(user);
			msg = "User added: " + user.getId();
		} catch (Exception e) {
			msg = "Unable to add user: " + user.getId();
			e.printStackTrace();
		}
		System.out.println("service add msg =" + msg);
		return msg;
	}

	@Override
	public String updateUser(User user) {
		// TODO
		String msg = "";
		try {
			userDao.updateUser(user);
			msg = "Unable to updated: " + user.getId();
		} catch (Exception e) {
			msg = "Unable to update user: " + user.getId();
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	public String deleteUser(String userId) {
		String msg = "";
		try {
			userDao.deleteUser(userId);
			msg = "User deleted: " + userId;
		} catch (Exception e) {
			msg = "Unable to delete user: " + userId;
			e.printStackTrace();
		}

		return msg;
	}

}
