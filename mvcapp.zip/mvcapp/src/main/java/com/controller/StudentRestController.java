package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.domain.Student;
import com.domain.Experiment_Type;

import com.service.StudentService;

@RestController
@RequestMapping("/rest")
public class StudentRestController {

	@Autowired
	StudentService studentService;

	@RequestMapping(value = "/createStudent", method = RequestMethod.POST)
	public Student createStudent(@RequestBody Student student) {
		Student createdStudent = studentService.createStudent(student);
		return createdStudent;
	}

	@RequestMapping(value = "/getStudent/{id}", method = RequestMethod.GET)
	public Student getStudent(@PathVariable("id") String studentId) {
		Student createdStudent = null;
		try {
			createdStudent = studentService.getStudent(studentId);
		} catch (Exception e) {
			// TODO: handle exception - student not found
		}
		return createdStudent;
	}

	@RequestMapping(value = "/getStudents", method = RequestMethod.GET)
	public List<Student> getStudents() {
		List<Student> createdStudent = studentService.getAllStudents();
		return createdStudent;
	}

	@RequestMapping(value = "/updateStudent", method = RequestMethod.PUT)
	public Student updateStudent(@RequestBody Student student) {
		Student createdStudent = null;
		try {
			createdStudent = studentService.updateStudent(student);
		} catch (Exception e) {
			// TODO: handle exception - student not updated
		}
		return createdStudent;
	}

	@RequestMapping(value = "/deleteStudent/{id}", method = RequestMethod.DELETE)
	public boolean deleteStudent(@PathVariable("id") String studentId) {
		boolean isDeleted = false;
		try {
			isDeleted = studentService.deleteStudent(studentId);
		} catch (Exception e) {
			// TODO: handle exception - student not deleted
		}
		return isDeleted;
	}
	@RequestMapping(value="/getExp",method=RequestMethod.GET)
	public List<Experiment_Type> getExperiments()
	{
		
		List<Experiment_Type> list=studentService.getExperiments();
		return list;
	}
	
	
}
