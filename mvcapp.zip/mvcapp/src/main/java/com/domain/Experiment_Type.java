package com.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Experiment_Type")
public class Experiment_Type implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "EXPERIMENT_TYPE_ID")
	private long experiment_type_id;
	
	@Column(name = "EXPERIMENT_TYPE_CODE")
	private String experiment_type_code;
	//private String experiment_type_description;
	
	
	public Experiment_Type(long experiment_type_id,
			String experiment_type_code) {
		super();
		this.experiment_type_id = experiment_type_id;
		this.experiment_type_code = experiment_type_code;
		//this.experiment_type_description = experiment_type_description;
	}
	public Experiment_Type() {
		super();
	}
	public long getExperiment_type_id() {
		return experiment_type_id;
	}
	public void setExperiment_type_id(long experiment_type_id) {
		this.experiment_type_id = experiment_type_id;
	}
	public String getExperiment_type_code() {
		return experiment_type_code;
	}
	public void setExperiment_type_code(String experiment_type_code) {
		this.experiment_type_code = experiment_type_code;
	}
	/*public String getExperiment_type_description() {
		return experiment_type_description;
	}
	public void setExperiment_type_description(String experiment_type_description) {
		this.experiment_type_description = experiment_type_description;
	}*/
	@Override
	public String toString() {
		return "Experiment_Type[id=" + experiment_type_id + ", name=" + experiment_type_code +"]";
	}

}
