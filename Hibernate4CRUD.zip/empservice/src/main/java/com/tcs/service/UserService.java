package com.tcs.service;

import java.util.List;

import com.tcs.domain.User;

public interface UserService {

	User getUser(String userId);

	List<User> getAllUsers();

	String saveUser(User user);

	String updateUser(User user);

	String deleteUser(String userId); 

}
