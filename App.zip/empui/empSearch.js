$(document).ready(function(){

	$.ajax({ 
		 type: "GET",
		 dataType: "json",
		 url: "http://localhost:8080/empservice/services/registration/getAll",
		 success: function(data){        
			alert("json: " + JSON.stringify(data));
		 }
	 });

});