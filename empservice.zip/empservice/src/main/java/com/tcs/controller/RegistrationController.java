package com.tcs.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.domain.User;
import com.tcs.service.UserService;

@RestController
@RequestMapping(value = "/registration")
public class RegistrationController {

	@Autowired
	private UserService userService;

	/**
	 * http://localhost:8080/empservice/services/registration/get
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/get/{userId}", method = RequestMethod.GET)
	public User getUser(@PathVariable String userId) {
		System.out.println("userId = " + userId);
		User user = userService.getUser(userId);
		return user;
	}

	/**
	 * http://localhost:8080/empservice/services/registration/getAll
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getAll", method = RequestMethod.GET)
	public List<User> getAllUsers() {
		List<User> users = userService.getAllUsers();
		return users;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String add(@RequestBody User user, HttpServletRequest request) {
		System.out.println("controller add user =" + user);
		String msg = userService.saveUser(user);
		System.out.println("controller add msg =" + msg);
		String jsonResponse = "{\"msg\" : \"" + msg + "\"}";
		System.out.println("controller add jsonResponse =" + jsonResponse);
		return jsonResponse;
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String update(@RequestBody User user, HttpServletRequest request) {
		String msg = userService.updateUser(user);
		return msg;
	}

	@RequestMapping(value = "/delete/{userId}", method = RequestMethod.POST)
	public String delete(@PathVariable String userId) {
		String msg = userService.deleteUser(userId);
		return msg;
	}
}
