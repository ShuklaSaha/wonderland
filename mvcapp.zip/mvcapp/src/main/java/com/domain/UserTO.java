package com.domain;

import java.io.Serializable;

public class UserTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private String userId;
	private String userName;
	private String password;
	private String status;
	private String roleId;
	private String roleName;
	private String permissionId;
	private String permissionName;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(String permissionId) {
		this.permissionId = permissionId;
	}

	public String getPermissionName() {
		return permissionName;
	}

	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

	@Override
	public String toString() {
		return "UserTO [userId=" + userId + ", userName=" + userName
				+ ", password=" + password + ", status=" + status + ", roleId="
				+ roleId + ", roleName=" + roleName + ", permissionId="
				+ permissionId + ", permissionName=" + permissionName + "]";
	}

}
