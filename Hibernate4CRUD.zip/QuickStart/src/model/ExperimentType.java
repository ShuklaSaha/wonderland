package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the experiment_type database table.
 * 
 */
@Entity
@Table(name="experiment_type")
@NamedQuery(name="ExperimentType.findAll", query="SELECT e FROM ExperimentType e")
public class ExperimentType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EXPERIMENT_TYPE_ID")
	private int experimentTypeId;

	@Column(name="EXPERIMENT_TYPE_CODE")
	private String experimentTypeCode;

	@Column(name="EXPERIMENT_TYPE_DESCRIPTION")
	private String experimentTypeDescription;

	public ExperimentType() {
	}

	public int getExperimentTypeId() {
		return this.experimentTypeId;
	}

	public void setExperimentTypeId(int experimentTypeId) {
		this.experimentTypeId = experimentTypeId;
	}

	public String getExperimentTypeCode() {
		return this.experimentTypeCode;
	}

	public void setExperimentTypeCode(String experimentTypeCode) {
		this.experimentTypeCode = experimentTypeCode;
	}

	public String getExperimentTypeDescription() {
		return this.experimentTypeDescription;
	}

	public void setExperimentTypeDescription(String experimentTypeDescription) {
		this.experimentTypeDescription = experimentTypeDescription;
	}

}